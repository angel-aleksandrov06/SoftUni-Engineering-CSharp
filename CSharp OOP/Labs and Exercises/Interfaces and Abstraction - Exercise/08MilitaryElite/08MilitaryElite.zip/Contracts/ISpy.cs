﻿namespace _08MilitaryElite.Contracts
{
    public interface ISpy : ISoldier
    {
        public int CodeNumber { get; }
    }
}