﻿namespace _08MilitaryElite.Enums
{
    public enum Corps
    {
        Airforces = 1,
        Marines = 2
    }
}