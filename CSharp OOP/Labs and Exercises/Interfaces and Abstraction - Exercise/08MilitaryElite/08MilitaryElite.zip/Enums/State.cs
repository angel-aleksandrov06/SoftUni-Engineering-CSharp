﻿namespace _08MilitaryElite.Enums
{
    public enum State
    {
        InProgress = 1,
        Finished = 2,
    }
}